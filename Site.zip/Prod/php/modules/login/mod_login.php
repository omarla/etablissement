<?php

	class Mod_Inscription{
		public function __construct(){
			$action = isset($_GET['action']) ? $_GET['action'] : null;

			if($action == null){
				
			} 
		}
	}

?>