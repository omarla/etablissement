<div class="container-fluid row justify-content-around administration">
    <div class="col-lg-3  px-0 container">

        <div class="list-group">
            <button type="button" class=" list-group-item list-group-item-action active">
                Utilisateurs
            </button>

            <button type="button" class="list-group-item list-group-item-action">
                Droits
            </button>
            <button type="button" class="list-group-item list-group-item-action">
                Modules
            </button>

        </div>

    </div>
    <div class="col-lg-8 container bg-light">
        <?php include_once "utilisateurs.php" ?>
    </div>

</div>